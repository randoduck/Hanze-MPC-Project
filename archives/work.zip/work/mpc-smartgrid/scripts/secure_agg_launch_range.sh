#!/usr/bin/env bash
set -euo pipefail

START_ID="${1:?missing start_id}"
END_ID="${2:?missing end_id}"
N="${3:?missing N}"
AGG_IP="${4:?missing aggregator_ip}"
PORT="${5:?missing port}"
MASK_KEY="${6:?missing mask_key}"
OUTDIR="${7:?missing outdir}"
MEM_KB="${8:?missing mem_kb}"
CPU_SECONDS="${9:?missing cpu_seconds}"

SCRIPT_PATH="$(readlink -f "$0")"
SCRIPT_DIR="$(dirname "$SCRIPT_PATH")"
REPO_DIR="$(dirname "$SCRIPT_DIR")"
cd "$REPO_DIR"
mkdir -p "$OUTDIR"

value_for_node() {
  local i="$1"
  echo $((100 + ((37*i + 11*i*i + 73) % 900)))
}

if (( START_ID > END_ID )); then
  exit 0
fi

for i in $(seq "$START_ID" "$END_ID"); do
  v="$(value_for_node "$i")"

  (
    ulimit -v "$MEM_KB"
    ulimit -n 64
    ulimit -t "$CPU_SECONDS"

    nice -n 10 timeout 300s ./build/secure_agg_meter \
      --id "$i" \
      --n "$N" \
      --value "$v" \
      --aggregator "$AGG_IP" \
      --port "$PORT" \
      --mask-key "$MASK_KEY" \
      > "${OUTDIR}/meter_${i}.out" 2>&1
  ) &
done

wait
