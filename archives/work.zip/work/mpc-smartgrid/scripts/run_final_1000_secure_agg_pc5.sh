#!/usr/bin/env bash
set -euo pipefail

PI5_HOST="solomon@100.101.20.65"
PI2_HOST="pi@100.85.83.7"

PI5_IP="100.101.20.65"
REPO_LOCAL="$HOME/Desktop/Work/Hanze/work/mpc-smartgrid"
REPO_REMOTE="~/mpc-smartgrid"

N=1000
PORT=7000
MASK_KEY="0x20260606ABCDEF01"

# Per-meter caps.
METER_MEM_KB=16384
METER_CPU_SECONDS=10

# Per-Pi group caps for all meter processes on that Pi.
PI5_GROUP_CPU="300%"
PI5_GROUP_MEM="1024M"
PI2_GROUP_CPU="100%"
PI2_GROUP_MEM="256M"

TIMEOUT_SEC=420
RUN_ID="$(date +%Y%m%d_%H%M%S)"
OUTDIR="$REPO_LOCAL/benchmark_results/final_1000_${RUN_ID}"

mkdir -p "$OUTDIR"

value_for_node() {
  local i="$1"
  echo $((100 + ((37*i + 11*i*i + 73) % 900)))
}

expected_sum() {
  local sum=0
  for ((i=0; i<N; i++)); do
    sum=$((sum + $(value_for_node "$i")))
  done
  echo "$sum"
}

EXPECTED="$(expected_sum)"

PI5_MEM_MB="$(ssh "$PI5_HOST" "awk '/MemAvailable/ {print int(\$2/1024)}' /proc/meminfo")"
PI2_MEM_MB="$(ssh "$PI2_HOST" "awk '/MemAvailable/ {print int(\$2/1024)}' /proc/meminfo")"

PI5_CORES="$(ssh "$PI5_HOST" "nproc")"
PI2_CORES="$(ssh "$PI2_HOST" "nproc")"

PI5_SCORE=$((PI5_MEM_MB * PI5_CORES))
PI2_SCORE=$((PI2_MEM_MB * PI2_CORES))
TOTAL_SCORE=$((PI5_SCORE + PI2_SCORE))

PI5_METERS=$((N * PI5_SCORE / TOTAL_SCORE))
PI2_METERS=$((N - PI5_METERS))

# Keep Pi 2 involved but avoid making this a Pi 2 overload test.
PI2_MIN=100
PI2_MAX=300

if (( PI2_METERS < PI2_MIN )); then
  PI2_METERS=$PI2_MIN
  PI5_METERS=$((N - PI2_METERS))
fi

if (( PI2_METERS > PI2_MAX )); then
  PI2_METERS=$PI2_MAX
  PI5_METERS=$((N - PI2_METERS))
fi

PI5_START=0
PI5_END=$((PI5_METERS - 1))
PI2_START=$PI5_METERS
PI2_END=$((N - 1))

echo "[final1000] expected aggregate = $EXPECTED"
echo "[final1000] Pi 5 MemAvailable=${PI5_MEM_MB}MB cores=${PI5_CORES} score=${PI5_SCORE}"
echo "[final1000] Pi 2 MemAvailable=${PI2_MEM_MB}MB cores=${PI2_CORES} score=${PI2_SCORE}"
echo "[final1000] placement: Pi5=${PI5_METERS} meters, Pi2=${PI2_METERS} meters"
echo "[final1000] Pi5 range: ${PI5_START}..${PI5_END}"
echo "[final1000] Pi2 range: ${PI2_START}..${PI2_END}"
echo "[final1000] per-meter caps: mem=${METER_MEM_KB}KB fd=64 cpu_seconds=${METER_CPU_SECONDS}"
echo "[final1000] group caps: Pi5 CPU=${PI5_GROUP_CPU} MEM=${PI5_GROUP_MEM}; Pi2 CPU=${PI2_GROUP_CPU} MEM=${PI2_GROUP_MEM}"

echo "[final1000] syncing source"
rsync -av --delete --exclude build/ --exclude logs/ --exclude benchmark_results/ \
  "$REPO_LOCAL/" "$PI5_HOST:~/mpc-smartgrid/" >/dev/null

rsync -av --delete --exclude build/ --exclude logs/ --exclude benchmark_results/ \
  "$REPO_LOCAL/" "$PI2_HOST:~/mpc-smartgrid/" >/dev/null

echo "[final1000] rebuilding"
ssh "$PI5_HOST" "cd $REPO_REMOTE && make clean && make"
ssh "$PI2_HOST" "cd $REPO_REMOTE && make clean && make"

echo "[final1000] verifying binaries"
ssh "$PI5_HOST" "cd $REPO_REMOTE && file build/secure_agg_server build/secure_agg_meter"
ssh "$PI2_HOST" "cd $REPO_REMOTE && file build/secure_agg_meter"

echo "[final1000] cleanup"
ssh "$PI5_HOST" "pkill -x secure_agg_server 2>/dev/null || true; pkill -x secure_agg_meter 2>/dev/null || true; fuser -k ${PORT}/tcp 2>/dev/null || true"
ssh "$PI2_HOST" "pkill -x secure_agg_meter 2>/dev/null || true"

echo "[final1000] start aggregator on Pi 5"
ssh "$PI5_HOST" "cd $REPO_REMOTE && mkdir -p logs/final_1000 && \
  tmux new-session -d -s final_agg \
  'ulimit -n 4096; timeout ${TIMEOUT_SEC}s ./build/secure_agg_server --n ${N} --port ${PORT} --expected ${EXPECTED} > logs/final_1000/aggregator.out 2>&1'"

sleep 3

echo "[final1000] launching Pi 5 meters under group cgroup"
ssh "$PI5_HOST" "cd $REPO_REMOTE && mkdir -p logs/final_1000/pi5 && \
  sudo systemd-run --scope --quiet \
    -p CPUQuota=${PI5_GROUP_CPU} \
    -p MemoryMax=${PI5_GROUP_MEM} \
    ./scripts/secure_agg_launch_range.sh \
      ${PI5_START} ${PI5_END} ${N} ${PI5_IP} ${PORT} ${MASK_KEY} logs/final_1000/pi5 ${METER_MEM_KB} ${METER_CPU_SECONDS}" &
PID_PI5=$!

echo "[final1000] launching Pi 2 meters under group cgroup"
ssh "$PI2_HOST" "cd $REPO_REMOTE && mkdir -p logs/final_1000/pi2 && \
  sudo systemd-run --scope --quiet \
    -p CPUQuota=${PI2_GROUP_CPU} \
    -p MemoryMax=${PI2_GROUP_MEM} \
    ./scripts/secure_agg_launch_range.sh \
      ${PI2_START} ${PI2_END} ${N} ${PI5_IP} ${PORT} ${MASK_KEY} logs/final_1000/pi2 ${METER_MEM_KB} ${METER_CPU_SECONDS}" &
PID_PI2=$!

STATUS="PASS"
REASON="ok"

if ! wait "$PID_PI5"; then
  STATUS="FAIL"
  REASON="pi5_meter_launch_failed_or_timed_out"
fi

if ! wait "$PID_PI2"; then
  STATUS="FAIL"
  REASON="${REASON};pi2_meter_launch_failed_or_timed_out"
fi

echo "[final1000] waiting for aggregator to finish"
sleep 10

echo "[final1000] collecting logs"
mkdir -p "$OUTDIR/pi5" "$OUTDIR/pi2"

rsync -av "$PI5_HOST:~/mpc-smartgrid/logs/final_1000/" "$OUTDIR/pi5/" >/dev/null || true
rsync -av "$PI2_HOST:~/mpc-smartgrid/logs/final_1000/" "$OUTDIR/pi2/" >/dev/null || true

AGG_LOG="$OUTDIR/pi5/aggregator.out"

echo "[final1000] aggregator log:"
cat "$AGG_LOG" || true

OBSERVED="$(grep 'OBSERVED_AGGREGATE' "$AGG_LOG" | awk -F'=' '{gsub(/[ \t]/, "", $2); print $2}' | tail -n 1 || true)"
RECEIVED="$(grep 'RECEIVED_COUNT' "$AGG_LOG" | awk -F'=' '{gsub(/[ \t]/, "", $2); print $2}' | tail -n 1 || true)"
WALL_MS="$(grep 'WALL_MS' "$AGG_LOG" | awk -F'=' '{gsub(/[ \t]/, "", $2); print $2}' | tail -n 1 || true)"
AGG_RSS="$(grep 'MAX_RSS_KB' "$AGG_LOG" | awk -F'=' '{gsub(/[ \t]/, "", $2); print $2}' | tail -n 1 || true)"

PI5_LOG_COUNT="$(find "$OUTDIR/pi5/pi5" -name 'meter_*.out' 2>/dev/null | wc -l || true)"
PI2_LOG_COUNT="$(find "$OUTDIR/pi2/pi2" -name 'meter_*.out' 2>/dev/null | wc -l || true)"

if [[ "$OBSERVED" != "$EXPECTED" ]]; then
  STATUS="FAIL"
  REASON="${REASON};aggregate_mismatch"
fi

if [[ "$RECEIVED" != "$N" ]]; then
  STATUS="FAIL"
  REASON="${REASON};received_${RECEIVED}_expected_${N}"
fi

cat > "$OUTDIR/final_1000_result.csv" <<EOF
N,pi5_meters,pi2_meters,pi5_start,pi5_end,pi2_start,pi2_end,per_meter_mem_kb,per_meter_fd_cap,per_meter_cpu_seconds,pi5_group_cpu,pi5_group_mem,pi2_group_cpu,pi2_group_mem,expected_aggregate,observed_aggregate,received_count,pi5_meter_logs,pi2_meter_logs,wall_ms,aggregator_rss_kb,status,reason
${N},${PI5_METERS},${PI2_METERS},${PI5_START},${PI5_END},${PI2_START},${PI2_END},${METER_MEM_KB},64,${METER_CPU_SECONDS},${PI5_GROUP_CPU},${PI5_GROUP_MEM},${PI2_GROUP_CPU},${PI2_GROUP_MEM},${EXPECTED},${OBSERVED},${RECEIVED},${PI5_LOG_COUNT},${PI2_LOG_COUNT},${WALL_MS},${AGG_RSS},${STATUS},${REASON}
EOF

echo "[final1000] result:"
cat "$OUTDIR/final_1000_result.csv"

echo "[final1000] output dir: $OUTDIR"
