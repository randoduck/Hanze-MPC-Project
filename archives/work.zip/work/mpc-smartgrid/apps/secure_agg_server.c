#include "mpc_field.h"

#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

#define MAGIC 0x4D504341u
#define MAX_CLIENTS 5000

typedef struct {
    uint32_t magic;
    uint32_t id;
    uint32_t masked_value;
} packet_t;

static double now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec / 1e6;
}

static void usage(const char *prog) {
    fprintf(stderr,
        "usage: %s --n N --port PORT --expected EXPECTED\n",
        prog);
}

static int recv_full(int fd, void *buf, size_t len) {
    uint8_t *p = (uint8_t *)buf;
    size_t got = 0;

    while (got < len) {
        ssize_t r = recv(fd, p + got, len - got, 0);
        if (r == 0) return -1;
        if (r < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        got += (size_t)r;
    }

    return 0;
}

int main(int argc, char **argv) {
    int n = -1;
    int port = -1;
    unsigned long expected_raw = 0;
    int have_expected = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--n") == 0 && i + 1 < argc) {
            n = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--port") == 0 && i + 1 < argc) {
            port = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--expected") == 0 && i + 1 < argc) {
            expected_raw = strtoul(argv[++i], NULL, 10);
            have_expected = 1;
        } else {
            usage(argv[0]);
            return 1;
        }
    }

    if (n <= 0 || n > MAX_CLIENTS || port <= 0 || !have_expected) {
        usage(argv[0]);
        return 1;
    }

    uint8_t *seen = calloc((size_t)n, sizeof(uint8_t));
    if (!seen) {
        perror("calloc seen");
        return 1;
    }

    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("socket");
        free(seen);
        return 1;
    }

    int yes = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons((uint16_t)port);

    if (bind(server_fd, (struct sockaddr *)&addr, sizeof(addr)) != 0) {
        perror("bind");
        close(server_fd);
        free(seen);
        return 1;
    }

    if (listen(server_fd, 4096) != 0) {
        perror("listen");
        close(server_fd);
        free(seen);
        return 1;
    }

    printf("[agg] secure aggregation server\n");
    printf("[agg] N=%d port=%d expected=%lu\n", n, port, expected_raw);
    printf("[agg] waiting for submissions...\n");
    fflush(stdout);

    double t0 = now_ms();

    uint64_t aggregate = 0;
    int received = 0;
    int duplicates = 0;
    int invalid = 0;

    while (received < n) {
        struct sockaddr_in peer;
        socklen_t peer_len = sizeof(peer);

        int client_fd = accept(server_fd, (struct sockaddr *)&peer, &peer_len);
        if (client_fd < 0) {
            if (errno == EINTR) continue;
            perror("accept");
            invalid++;
            continue;
        }

        packet_t pkt;
        if (recv_full(client_fd, &pkt, sizeof(pkt)) != 0) {
            close(client_fd);
            invalid++;
            continue;
        }

        close(client_fd);

        uint32_t magic = ntohl(pkt.magic);
        uint32_t id = ntohl(pkt.id);
        uint32_t masked_value = ntohl(pkt.masked_value);

        if (magic != MAGIC || id >= (uint32_t)n || masked_value >= MPC_PRIME) {
            invalid++;
            continue;
        }

        if (seen[id]) {
            duplicates++;
            continue;
        }

        seen[id] = 1;
        received++;

        aggregate += masked_value;
        aggregate %= MPC_PRIME;

        if (received % 100 == 0 || received == n) {
            printf("[agg] received=%d/%d\n", received, n);
            fflush(stdout);
        }
    }

    double t1 = now_ms();

    struct rusage ru;
    getrusage(RUSAGE_SELF, &ru);

    uint64_t expected = expected_raw % MPC_PRIME;
    const char *status = (aggregate == expected && received == n) ? "PASS" : "FAIL";

    printf("[agg] ============================\n");
    printf("[agg] RECEIVED_COUNT      = %d\n", received);
    printf("[agg] DUPLICATES          = %d\n", duplicates);
    printf("[agg] INVALID             = %d\n", invalid);
    printf("[agg] EXPECTED_AGGREGATE  = %lu\n", (unsigned long)expected);
    printf("[agg] OBSERVED_AGGREGATE  = %lu\n", (unsigned long)aggregate);
    printf("[agg] WALL_MS             = %.3f\n", t1 - t0);
    printf("[agg] MAX_RSS_KB          = %ld\n", ru.ru_maxrss);
    printf("[agg] STATUS              = %s\n", status);
    printf("[agg] ============================\n");

    close(server_fd);
    free(seen);

    return strcmp(status, "PASS") == 0 ? 0 : 1;
}
